import tkinter as tk
from tkinter import filedialog, messagebox
import os
from tkinter import Tk
from PIL import Image, ImageTk
from tkinter import filedialog, messagebox, Menu
import json


class FTE:
    def __init__(self, root):
        self.root = root
        self.file_path = None
        self.menu_frame = tk.Frame(self.root, width=20, bg="lightgray")
        self.menu_frame.pack_propagate(0)
        self.menu_frame.pack(side="left", fill="y")
        self.root.title("Fast Text Editor - Untitled.txt")
        root.geometry("600x380")

        self.text_edit_stack = []

        # 加载JSON配置
        current_directory = os.path.dirname(__file__)
        config_path = os.path.join(current_directory, "FTE", "config.json")

        with open(config_path, 'r') as file:
            config_data = json.load(file)
            text_area_background_color = config_data.get("text_area_background_color", "white")
            text_area_font_color = config_data.get("text_area_font_color", "black")
            text_area_border_size = config_data.get("text_area_border_size", "1")
            text_area_font = config_data.get("text_area_font", "TkFixedFont")
            text_area_relief = config_data.get("text_area_relief", "groove")

        # 加载图标文件并转换为Tkinter可用的格式
        current_directory = os.path.dirname(os.path.realpath(__file__))
        icon_path = os.path.join(current_directory, 'FTE', 'icon.ico')
        img = Image.open(icon_path)
        icon_img = ImageTk.PhotoImage(img)
        self.root.tk.call('wm', 'iconphoto', self.root._w, icon_img)

        # File菜单栏
        menubar = tk.Menu(self.root)
        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="New", command=self.new_file_prompt)
        file_menu.add_command(label="Open", command=self.open_file_with_prompt)
        file_menu.add_command(label="Save", command=self.save_file)
        file_menu.add_command(label="Save As...", command=self.save_file_as)
        file_menu.add_command(label="New Window", command=self.new_window)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.confirm_exit)
        menubar.add_cascade(label="File", menu=file_menu)
        self.root.config(menu=menubar)

        # Edit栏
        edit_menu = Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Edit", menu=edit_menu)
        edit_menu.add_command(label="Undo", command=self.undo_action)
        edit_menu.add_command(label="Redo", command=self.redo_action)
        edit_menu.add_separator()
        edit_menu.add_command(label="Cut", command=self.cut_text)
        edit_menu.add_command(label="Copy", command=self.copy_text)
        edit_menu.add_command(label="Paste", command=self.paste_text)

        # 文本编辑区域
        self.text_area = tk.Text(self.root,
                                 wrap="word",
                                 bg=text_area_background_color,
                                 fg=text_area_font_color,
                                 bd=text_area_border_size,
                                 font=text_area_font,
                                 relief=text_area_relief)
        self.text_area.pack(expand=True, fill="both")

    def new_file_prompt(self):
        if not (self.text_area.get("1.0", "end-1c") or self.file_path):
            self.new_file()
        else:
            response = messagebox.askyesno("Unsaved Changes",
                                       "Are you sure you want to create a new file? The text may not be saved.")
            if response:  # True for Yes, False for No
                self.new_file()

    def new_file(self):
        self.text_area.delete(1.0, "end")
        self.file_path = None
        self.root.title("Fast Text Editor - Untitled.txt")

    def confirm_exit(self):
        if not (self.text_area.get("1.0", "end-1c") or self.file_path):
            self.root.quit()
            return

        response = messagebox.askyesnocancel("Unsaved Changes",
                                             "Are you sure you want to exit? The text may not be saved.")
        if response:  # True for Yes, False for No, None for Cancel
            if response is True:
                self.save_file()
            self.root.quit()

    def open_file_with_prompt(self):
        if self.text_area.get("1.0", "end-1c") != "":
            response = messagebox.askyesno("Unsaved Changes",
                                           "What you entered may not have been saved.\nAre you sure you want to continue?")
            if not response:
                return
        self.open_file()

    def open_file(self):
        self.file_path = filedialog.askopenfilename()
        if self.file_path:
            with open(self.file_path, "r") as file:
                text_content = file.read()
                self.text_area.delete(1.0, "end")
                self.text_area.insert("end", text_content)
                file_name = os.path.basename(self.file_path)
                self.root.title(f"Fast Text Editor - {file_name}")

    def save_file(self):
        if self.file_path:
            with open(self.file_path, "w") as file:
                file.write(self.text_area.get("1.0", "end-1c"))
        else:
            self.save_file_as()

    def save_file_as(self):
        self.file_path = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text files", "*.txt")])
        if self.file_path:
            with open(self.file_path, "w") as file:
                file.write(self.text_area.get("1.0", "end-1c"))
            file_name = os.path.basename(self.file_path)
            self.root.title(f"Fast Text Editor - {file_name}")

    def cut_text(self):
        self.text_area.event_generate("<<Cut>>")
    
    def copy_text(self):
        self.text_area.event_generate("<<Copy>>")

    def paste_text(self):
      self.text_area.event_generate("<<Paste>>")

    def new_window(self):
        new_root = tk.Toplevel(self.root)
        editor = FTE(new_root)

    def undo_action(self):
        if self.text_edit_stack:
            last_text = self.text_edit_stack.pop()
            self.text_area.delete("1.0", tk.END)
            self.text_area.insert(tk.END, last_text)

    def redo_action(self):
        if self.text_area.edit_modified():
            self.text_area.edit_redo()

if __name__ == "__main__":
    root = Tk()
    editor = FTE(root)
    root.mainloop()

